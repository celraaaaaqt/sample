document.getElementById("home").addEventListener("click", function() {
    window.location.href = "home.html";  // Redirects to home.html
});
document.getElementById("about").addEventListener("click", function() {
    window.location.href = "about.html";  // Redirects to home.html
});
